package com.example.pizza;

import javafx.collections.FXCollections;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class HelloController {
    public TextField customername;
    public TextField mobilenumber;
    public CheckBox sizeXL;
    public CheckBox sizeL;
    public CheckBox sizeM;
    public CheckBox sizeS;
    public TextField numberoftoppings;
    public TableColumn icustomername;
    public TableColumn imobilenumber;
    public TableColumn ipizzasize;
    public TableColumn itoppings;
    public TableColumn itotalbill;
    public TableView tableview;
    @FXML
    private Label welcomeText;
    private TableView<Object> tableView;
    SortedList<Object> list = FXCollections.observableArrayList().sorted();
    private Object totalbill;

    public void initialize(URL url, ResourceBundle resourceBundle) {

        icustomername.setCellValueFactory(new PropertyValueFactory<pizza, Integer>("customername"));
        imobilenumber.setCellValueFactory(new  PropertyValueFactory<pizza, String>("mobilenumber"));
        ipizzasize.setCellValueFactory(new  PropertyValueFactory<pizza, String>("pizzasize"));
        itoppings.setCellValueFactory(new PropertyValueFactory<pizza, Integer>("toppings"));

        tableView.setItems(list);
    }
    @FXML
    protected void onHelloButtonClick() {
        list.clear();
        tableView.setItems(list);

        populateTable();
    }
    public void populateTable() {

        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/pizza";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM admin";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            // Populate the table with data from the database
            while (resultSet.next()) {
                int mobilenumber = resultSet.getInt("mobilenumber");
                String customername = resultSet.getString("customername");
                String pizzasize = resultSet.getString("pizzasize");
                int toppings= resultSet.getInt("toppings");

                tableView.getItems().add(new pizza(customername, mobilenumber, pizzasize, toppings, totalbill));


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void createclick(ActionEvent actionEvent) {
        String getmobilenumber = imobilenumber.getText();
        String getcustomername = icustomername.getText();
        String getpizzasize= ipizzasize.getText();
        String gettoppings = itoppings.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/pizza";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO admin(customername, pizzasize, toppings,'mobilenumber') VALUES ('" + getcustomername+ "','" + getpizzasize+ "','" + gettoppings + "','"+getmobilenumber+"')";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void deleteclick(ActionEvent actionEvent) {

        String getcustomername = icustomername.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/pizza";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "DELETE FROM admin WHERE customername= '" + getcustomername + "' ";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void readclick(ActionEvent actionEvent) {

        String getcustomername= icustomername.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/pizza";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM admin WHERE id=" + getcustomername+ " ";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement. executeQuery(query);

            // Populate the table with data from the database
            while (resultSet.next()) {
                String customername= resultSet.getString("customername");
                int mobilenumber = resultSet.getInt("mobilenumber");
                String pizzasize = resultSet.getString("pizzasize");
                int toppings = resultSet.getInt("toppings");

                icustomername.setText(customername);
                imobilenumber.setText(String.valueOf(mobilenumber));
                ipizzasize.setText(String.valueOf(pizzasize));
                itoppings.setText(String.valueOf(toppings));

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void updateclick(ActionEvent actionEvent) {

        String getcustomername = icustomername.getText();
        String getmobilenumber = imobilenumber.getText();
        String getpizzasize = ipizzasize.getText();
        String gettoppings = itoppings.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/pizza";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "UPDATE admin SET toppings='" + gettoppings + "',mobilenumber='" + getmobilenumber + "',pizzasize='" + getpizzasize + "' WHERE customername = '" + getcustomername + "'";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}